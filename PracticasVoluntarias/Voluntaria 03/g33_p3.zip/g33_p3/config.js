"use strict";

/* Datos de conexión a la BD */
module.exports = {
    host: "localhost",     // Ordenador que ejecuta el SGBD
    user: "root",          // Usuario que accede a la BD
    password: "",          // Contraseña con la que se accede a la BD
    database: "aw_tareas"  // Nombre de la base de datos
};