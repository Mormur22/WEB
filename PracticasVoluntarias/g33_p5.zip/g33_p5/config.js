"use strict"

//Archivo de configuracion, realizar cambios necesarios para conexion a la base de datos.

"use strict"

//Archivo de configuracion, realizar cambios necesarios para conexion a la base de datos.

module.exports ={
    mysqlConfig:  {
        host: "localhost",
        user: "root",
        password: "",
        database: "aw_tareas",
    },
    port: 3306
};



