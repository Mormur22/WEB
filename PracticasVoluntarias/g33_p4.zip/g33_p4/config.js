"use strict"

//Archivo de configuracion, realizar cambios necesarios para conexion a la base de datos.

module.exports ={
   mysqlConfig:  {
        host:"aw-db.cilmfqfwy9bi.eu-west-3.rds.amazonaws.com",
        user:"admin",
        password: "Adminucm22",
        database:"aw_tareas"
    },
    port: 3306
};

