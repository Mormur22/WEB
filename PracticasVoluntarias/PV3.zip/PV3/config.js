"use strict"

//Archivo de configuracion, realizar cambios necesarios para conexion a la base de datos.

module.exports ={
   databaseConfig:  {
        host:"127.0.0.1",
        user:"admin",
        password: "",
        database:"pv3bd"
    } ,
    puerto: 3306
};


